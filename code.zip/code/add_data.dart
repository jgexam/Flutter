import 'package:flutter/material.dart';

class AddData extends StatefulWidget {
  const AddData({super.key});

  @override
  State<AddData> createState() => _AddDataState();
}

class _AddDataState extends State<AddData> {

  TextEditingController fname = TextEditingController();
  TextEditingController lname = TextEditingController();
  TextEditingController email = TextEditingController();

  String msg="";

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text('Add data screen'),
        centerTitle: true,
        backgroundColor: Colors.blueGrey,
      ),

      body: Padding(
        padding: const EdgeInsets.all(25.0),
        child: Column(
          children: [
            Icon(Icons.person_2,size: 50,),
            SizedBox(height: 20,),
        
            TextField(
              controller: fname,
              decoration: InputDecoration(
                labelText: "Enter Fname",
                prefix: Icon(Icons.person),
                border: OutlineInputBorder(),
              ),
            ),
            
            SizedBox(height: 15,),
        
            TextField(
              controller: lname,
              decoration: InputDecoration(
                labelText: "Enter Lname",
                prefix: Icon(Icons.person),
                border: OutlineInputBorder(),
              ),
            ),
        
            SizedBox(height: 15,),
        
            TextField(
              controller: email,
              decoration: InputDecoration(
                labelText: "Enter Email",
                prefix: Icon(Icons.email),
                border: OutlineInputBorder(),
              ),
            ),
        
            SizedBox(height: 20,),

            OutlinedButton(onPressed: (){

              // setState(() {
              //   if(fname == null )
              // {
              //     msg = "Your feild is empty";
              // }
              // else{
              //     msg = "valid data";
              // }
              // });

            }, child: Text("Submit")),

            // Text(msg),
        
          ],
        ),
      ),

    );
  }
}