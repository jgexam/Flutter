import 'package:flutter/material.dart';

class CalcScreen extends StatefulWidget {
  const CalcScreen({super.key});

  @override
  State<CalcScreen> createState() => _CalcScreenState();
}

class _CalcScreenState extends State<CalcScreen> {
  String num1 = "";
  String num2 = "";
  String result = "";

  // Function of addition
  void addNumbers() {
    double n1 = double.parse(num1);
    double n2 = double.parse(num2);
    setState(() {
      result = (n1 + n2).toString();
    });
  }

  // Function of subtraction
  void subtractNumbers() {
    double n1 = double.parse(num1);
    double n2 = double.parse(num2);
    setState(() {
      result = (n1 - n2).toString();
    });
  }

  // Function of multiplication
  void multiplyNumbers() {
    double n1 = double.parse(num1);
    double n2 = double.parse(num2);
    setState(() {
      result = (n1 * n2).toString();
    });
  }

  // Function of division
  void divideNumbers() {
    double n1 = double.parse(num1);
    double n2 = double.parse(num2);
    setState(() {
      if (n2 != 0) {
        result = (n1 / n2).toString(); // Prevent division by zero
      } else {
        result = "Error! Division by 0";
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Calculator'),
        backgroundColor: Colors.amber,
        leading: const Icon(Icons.calculate_outlined),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.settings)),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            // First textfield
            TextField(
              keyboardType: TextInputType.number,  // Restrict input to numbers
              onChanged: (value) {
                setState(() {
                  num1 = value;
                });
              },
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.numbers),
                hintText: 'Enter first number',
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 20.0),

            // Second textfield
            TextField(
              keyboardType: TextInputType.number,
              onChanged: (value) {
                setState(() {
                  num2 = value;
                });
              },
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.numbers),
                hintText: 'Enter second number',
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 20.0),

            // Display result
            Text(
              'Result: $result', 
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),

            const SizedBox(height: 30.0),

            // First row of buttons (+ and -)
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: addNumbers,
                  child: const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                    child: Text('+'),
                  ),
                ),
                const SizedBox(width: 50.0),
                ElevatedButton(
                  onPressed: subtractNumbers,
                  child: const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                    child: Text('-'),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20.0),

            // Second row of buttons (* and /)
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: multiplyNumbers,
                  child: const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                    child: Text('*'),
                  ),
                ),
                const SizedBox(width: 50.0),
                ElevatedButton(
                  onPressed: divideNumbers,
                  child: const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                    child: Text('/'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}