import 'package:flutter/material.dart';

class NotificationScreen extends StatelessWidget {
  const NotificationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("ListView"),
        backgroundColor: Colors.blueGrey,
      ),
      // body: ListView.builder(itemBuilder: (context,position){
      //   return Padding(
      //     padding: const EdgeInsets.all(10.0),
      //     child: Card(
      //       //child: Text("hello : ${position + 1}"),
      //       child: Text(position.toString()),
      //       surfaceTintColor: Colors.blueGrey,
      //       elevation: 20,
      //       shadowColor: Colors.grey,
      //       shape: RoundedRectangleBorder(
      //         borderRadius: BorderRadius.circular(10),
      //       ),
      //     ),
      //   );
      // },
      // itemCount: 50,
      // ),

      body : ListView.separated(itemBuilder: (context,position) {
        // return Text("22/8/24");
        return const Divider(
            color: Colors.black,
            height: 5,
        );
      }, 
      separatorBuilder: (context,position){
        // return OutlinedButton(onPressed: (){}, child: Text('i am seprator'));
        // return Column(
        //   children: [
        //     Text("hello good morning"),
        //     Text("hello good morning"),
        //     Text("hello good morning"),
        //     Text("hello good morning"),
        //     Text("hello good morning"),
        //   ],
        // );
        return const ListTile(
          // leading: Icon(Icons.notification_add_outlined),
          leading: CircleAvatar(backgroundColor: Colors.amber,backgroundImage: NetworkImage("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSJkNaVFoSOGFCsW1ngxQ0gMWuZWkQu3-NWRA&s"),),
          title: Text('whatsapp'),
          subtitle: Text('3 new msg'),
          //trailing: Icon(Icons.check),
          trailing: Column(
            children: [
              Text('12:00 Am'),
              Icon(Icons.check,size: 15.0),
            ],
          ),
        );
      }, itemCount: 5)
    );
  }
}