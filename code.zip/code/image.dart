import 'package:flutter/material.dart';

class Imagee extends StatelessWidget {
  const Imagee({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("image screen"),
        backgroundColor: Colors.amber,
      ),

      body: Column(
        children: [
          Image.asset("assets/image/coffee.png",height: 200,width: 200),
          Image.network("https://t4.ftcdn.net/jpg/01/05/90/77/360_F_105907729_4RzHYsHJ2UFt5koUI19fc6VzyFPEjeXe.jpg")
        ],
      ),
    );
  }
}