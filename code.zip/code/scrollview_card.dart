import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

class Scrollview extends StatelessWidget {
  const Scrollview({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Scroll view"),
        backgroundColor: Colors.purple,
      ),

      body: SingleChildScrollView(
        child: Column(
        children: [
          Card(
             color: Colors.blue[50],
             surfaceTintColor: Colors.amber,
             shadowColor: Colors.black,
             elevation: 10.0,
             borderOnForeground: true,
             shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(5),
              side: const BorderSide(
                width: 1,
                color: Colors.black
              ),
             ),
             child: Padding(padding: const EdgeInsets.all(20),
             child: Text.rich(
                TextSpan(
                  text: "If you Dont Have An Account?",
                  children: [
                    TextSpan(
                      text: "Click here",
                      style: const TextStyle(fontSize: 12.0,fontStyle: FontStyle.italic,color: Colors.blue),
                      recognizer: TapGestureRecognizer()..onTap=(){
                        print("you have printed....");
                      }
                    ),
                  ],
                ),
             ),
             ), 
          ),
        ],
       ),
      ), 

    );
  }
}