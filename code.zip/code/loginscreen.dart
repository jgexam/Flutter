import 'package:flutter/material.dart';

class Loginscreen extends StatelessWidget {
  const Loginscreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('login'),
        backgroundColor: Colors.purple,
      ),

      body: Padding(padding: const EdgeInsets.all(30.0),
            child: Column(children: [
        const Text('login page'),
        const SizedBox(height: 30.0),
        TextField(
          decoration: InputDecoration(
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(15)
            ),
            labelText: "Enter your email",
            helperText: "Nandini@gmail.com",
            hintText: "your email",
            //hintStyle: TextStyle(color: Colors.amber),
            prefixIcon: const Icon(Icons.email),
          ),
        ),

        const SizedBox(height: 30.0),
        TextField(
          obscureText: true,
          decoration: InputDecoration(
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(15)
            ),
            labelText: "Password",
            hintText: "your password",
            helperText: "must contain special character",
            //hintStyle: TextStyle(color: Colors.amber),
            prefixIcon: const Icon(Icons.password),
          ),
        ),
        const SizedBox(height: 30.0),
        // TextButton(onPressed: (){ }, child: Text("login")),
        // OutlinedButton(onPressed: () { }, child: Text("login")),
        ElevatedButton(onPressed: () { }, child: const Text("login")),
        // IconButton(onPressed: () { }, icon: Icon(Icons.home_filled)),
        // FloatingActionButton(onPressed: (){ },child: Icon(Icons.abc)),

          

      ],),
      )
    );
  }
}