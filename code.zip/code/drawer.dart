import 'package:first/Screens/loginscreen.dart';
import 'package:flutter/material.dart';

class DrawerScreen extends StatelessWidget {
  const DrawerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Drawer'),
        centerTitle: true,
        backgroundColor: Colors.grey,
        //leading: Icon(Icons.menu),
        actions: [
          IconButton(onPressed: (){}, icon: const Icon(Icons.notifications))
        ],
      ),

      drawer: Drawer(
        backgroundColor: const Color.fromARGB(255, 195, 220, 229),
        child: ListView(
          children:<Widget> [
            UserAccountsDrawerHeader(
              accountName: const Text('Nandini'), 
              accountEmail: const Text('nandini@gmail.com'),
              onDetailsPressed: () {
                
              },
              otherAccountsPictures: const [
                 CircleAvatar(
                backgroundImage: NetworkImage("https://as2.ftcdn.net/v2/jpg/03/48/53/09/1000_F_348530913_oyDmqo8YVn6AF7bTLOgOdhTS5QKJreiW.jpg"),
                ),
              ],
              currentAccountPicture: const CircleAvatar(
                backgroundImage: NetworkImage("https://as2.ftcdn.net/v2/jpg/03/48/53/09/1000_F_348530913_oyDmqo8YVn6AF7bTLOgOdhTS5QKJreiW.jpg"),
               ),
              ),
              ListTile(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>const Loginscreen()));
                  },
                leading: const Icon(Icons.home),
                title: const Text('Home'),
              ),
              
              const SizedBox(height: 20,),
              const Divider(height: 1.0,),
              const SizedBox(height: 20,),
              ListTile(
                onTap: (){},
                leading: const Icon(Icons.person),
                title: const Text('Profile'),
              ),
          ],
        ),
      ),
    );
  }
}