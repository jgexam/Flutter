import 'package:flutter/material.dart';

class SuccessOrders extends StatelessWidget {
  const SuccessOrders({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text("Success Orders"),
    );
  }
}