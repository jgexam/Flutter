import 'package:flutter/material.dart';

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {

  String num1 = "";
  String num2 = "";
  String result = "";

  void addnum()
  {
    double n1 = double.parse(num1);
    double n2 = double.parse(num2);
    setState(() {
      result=(n1+n2).toString();
    });
  }

  void subnum()
  {
    double n1 = double.parse(num1);
    double n2 = double.parse(num2);
    setState(() {
      result = (n1 - n2).toString();
    });
  }

  void mulnum()
  {
    double n1 = double.parse(num1);
    double n2 = double.parse(num2);
    setState(() {
      result = (n1 * n2).toString();
    });
  }

  void divnum()
  {
    double n1 = double.parse(num1);
    double n2 = double.parse(num2);
    setState(() {
      if(n1!=0)
      {
        result = (n1/n2).toString();
      }
      else
      {
        result = "error division by 0";
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Calculator"),
        backgroundColor: Colors.amberAccent,
        centerTitle: true,
        leading: Icon(Icons.calculate_outlined),
      ),

      body: Column(
        children: [
          SizedBox(height: 20,),
          TextField(
            keyboardType: TextInputType.number,
            onChanged: (value) {
              setState(() {
                num1 = value;
               }
              );
            },
            decoration: InputDecoration(
              hintText: "Enter 1 number",
              border: OutlineInputBorder(),
            ),
          ),
          SizedBox(height: 20,),

          TextField(
            keyboardType: TextInputType.number,
            onChanged: (value) {
              setState(() {
                num2 = value;
              });
            },

            decoration: InputDecoration(
              hintText: "Enter 2 number",
              border: OutlineInputBorder(),
            ),
          ),

          SizedBox(height: 20,),

          Text("Result : $result",style: TextStyle(fontSize: 24,fontWeight: FontWeight.bold),),

          SizedBox(height: 20,),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(onPressed: addnum, child: Text('+')),

              SizedBox(width: 50,),

              ElevatedButton(onPressed: subnum, child: Text('-')),
            ],
          ),

          SizedBox(height: 20,),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,

            children: [
              ElevatedButton(onPressed: mulnum, child: Text('*')),

              SizedBox(width: 50,),

              ElevatedButton(onPressed: divnum, child: Text('/')),
            ],
          ),
          
        ],
      ),
    );
  }
}