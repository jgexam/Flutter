import 'package:flutter/material.dart';

class Bottombar extends StatefulWidget {
  const Bottombar({super.key});

  @override
  State<Bottombar> createState() => _BottombarState();
}

class _BottombarState extends State<Bottombar> {

  int _position = 0;
  void selecteditem(int index)
  {
    setState(() {
      _position = index;
    });
  }

  static List<Widget> name = [
    Text("Home"),
    Text("Profile"),
    Text("Settings"),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Bottam bar Demo"),
        centerTitle: true,
        backgroundColor: Colors.amber,
      ),

      body: Center(
        child: name.elementAt(_position),
      ),

      bottomNavigationBar: BottomNavigationBar(items: [
        BottomNavigationBarItem(icon: Icon(Icons.home),label: "Home"),
        BottomNavigationBarItem(icon: Icon(Icons.person),label:"Profile"),
        BottomNavigationBarItem(icon: Icon(Icons.search),label:"Settings"),
      ],
      backgroundColor: Colors.green,
      onTap: selecteditem,
      currentIndex: _position,),
    );
  }
}