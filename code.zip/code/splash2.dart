import 'package:flutter/material.dart';

class Splash2 extends StatelessWidget {
  const Splash2({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("SPLASH SCREEN"),
        backgroundColor: Colors.amber,
      ),
      body: Text("Helloooooo Frndsssss"),
    );
  }
}